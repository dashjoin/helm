{{/*
Expand the name of the chart.
*/}}
{{- define "dashjoin.name" -}}
{{- (required "Need to specify .Values.name" .Values.name) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "dashjoin.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := .Release.Name }}
{{- if contains $name .Values.name }}
{{- .Values.name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Values.name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dashjoin.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "dashjoin.labels" -}}
helm.sh/chart: {{ include "dashjoin.chart" . }}
{{ include "dashjoin.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "dashjoin.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dashjoin.name" . }}
app.kubernetes.io/instance: {{ .Values.name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "dashjoin.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "dashjoin.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Compute the Dashjoin container image to use
Convenience that takes devMode and preRelease into account
*/}}
{{- define "dashjoin.image" }}
{{- if .Values.dashjoin.preRelease }}
{{- ternary "ghcr.io/dashjoin/dev-build" "ghcr.io/dashjoin/platform-build" .Values.dashjoin.devMode }}
{{- else }}
{{- ternary "dashjoin/studio" "dashjoin/platform" .Values.dashjoin.devMode }}
{{- end }}
{{- end }}

{{/*
Render merged environment variable arrays by deduplicating keys (overrides take priority).

Note: the best practise to use merged maps loses the order of env definitions (sometimes required)

Usage: {{ include "dashjoin.mergeEnv" (dict "default" .Values.defaultEnv "override" .Values.env "root" $) }}
*/}}
{{- define "dashjoin.mergeEnv" -}}
  {{- $default := .default | default list -}}
  {{- $override := .override | default list -}}
  {{- $root := .root -}}

  {{- /* Create an empty scratch map to track names we have already added */ -}}
  {{- $seen := dict -}}
  
  {{- /* 1. Find user overrides first (they take priority) */ -}}
  {{- range $override }}
    {{- if .name }}
      {{- $_ := set $seen .name true }}
    {{- end }}
  {{- end }}
# Default env values
  {{- /* 2. Process defaults only if the name hasn't been seen yet */ -}}
  {{- range $default }}
    {{- if .name }}
      {{- if not (hasKey $seen .name) }}
- name: {{ .name }}
  value: {{ tpl (toString .value) $root | quote }}
      {{- end }}
    {{- end }}
  {{- end }}
# User defined env from values.yml
  {{- /* 3. User overrides at end (add at last to minimize diffs with previous helm version) */ -}}
  {{- range $override }}
    {{- if .name }}
      {{- $_ := set $seen .name true }}
- name: {{ .name }}
  {{- if .value }}
  value: {{ tpl (toString .value) $root | quote }}
  {{- else}}
  valueFrom:
{{- .valueFrom | toYaml | nindent 4 }}
  {{- end }}
    {{- end }}
  {{- end }}  
{{- end -}}
