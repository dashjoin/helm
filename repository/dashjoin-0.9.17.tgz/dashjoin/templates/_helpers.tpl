{{/*
Expand the name of the chart.
*/}}
{{- define "dashjoin.name" -}}
{{- (required "Need to specify .Values.name" .Values.name) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "dashjoin.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := .Release.Name }}
{{- if contains $name .Values.name }}
{{- .Values.name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Values.name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dashjoin.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "dashjoin.labels" -}}
helm.sh/chart: {{ include "dashjoin.chart" . }}
{{ include "dashjoin.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "dashjoin.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dashjoin.name" . }}
app.kubernetes.io/instance: {{ .Values.name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "dashjoin.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "dashjoin.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Compute the Dashjoin container image to use
Convenience that takes devMode and preRelease into account
*/}}
{{- define "dashjoin.image" }}
{{- if .Values.dashjoin.preRelease }}
{{- ternary "ghcr.io/dashjoin/dev-build" "ghcr.io/dashjoin/platform-build" .Values.dashjoin.devMode }}
{{- else }}
{{- ternary "dashjoin/studio" "dashjoin/platform" .Values.dashjoin.devMode }}
{{- end }}
{{- end }}

{{/*
Render merged environment variable arrays by deduplicating keys (overrides take priority).

Note: the best practise to use merged maps loses the order of env definitions (sometimes required)

Usage: {{ include "dashjoin.mergeEnv" (dict "default" .Values.defaultEnv "override" .Values.env "root" $) }}
*/}}
{{- define "dashjoin.mergeEnv" -}}
  {{- $default := .default | default list -}}
  {{- $override := .override | default list -}}
  {{- $root := .root -}}

  {{- /* Create an empty scratch map to track names we have already added */ -}}
  {{- $seen := dict -}}
  
  {{- /* 1. Find user overrides first (they take priority) */ -}}
  {{- range $override }}
    {{- if .name }}
      {{- $_ := set $seen .name true }}
    {{- end }}
  {{- end }}
# Default env values
  {{- /* 2. Process defaults only if the name hasn't been seen yet */ -}}
  {{- range $default }}
    {{- if .name }}
      {{- if not (hasKey $seen .name) }}
- name: {{ .name }}
  value: {{ tpl (toString .value) $root | quote }}
      {{- end }}
    {{- end }}
  {{- end }}
# User defined env from values.yml
  {{- /* 3. User overrides at end (add at last to minimize diffs with previous helm version) */ -}}
  {{- range $override }}
    {{- if .name }}
      {{- $_ := set $seen .name true }}
- name: {{ .name }}
  {{- if .value }}
  value: {{ tpl (toString .value) $root | quote }}
  {{- else}}
  valueFrom:
{{- .valueFrom | toYaml | nindent 4 }}
  {{- end }}
    {{- end }}
  {{- end }}  
{{- end -}}

{{/*
=====================================================================
Secrets handling (see README "Secrets")
=====================================================================
*/}}

{{/* Name of the Secret unsealed from .Values.secrets.encryptedData */}}
{{- define "dashjoin.secretName" -}}
{{- .Values.secrets.name | default "dashjoin-secrets" -}}
{{- end }}

{{/* Name of the Secret holding auto-generated values (.Values.secrets.generate) */}}
{{- define "dashjoin.generatedSecretName" -}}
{{- printf "%s-generated" (include "dashjoin.secretName" .) -}}
{{- end }}

{{/*
Compute env entries that reference secrets for one component.

An entry is only added if
  - secrets.enabled is true,
  - secrets.env.<component> maps the env var to a secret key,
  - the env var is NOT already defined in the component's env (user values win,
    which allows a step by step migration away from plaintext env values),
  - the key is provided by one of the secret sources:
      1. secrets.generate        -> <name>-generated Secret
      2. secrets.existingSecret  -> pre-existing Secret (optional ref, keys are unknown)
      3. secrets.encryptedData   -> Secret unsealed from the SealedSecret

Returns a JSON list (use fromJsonArray).

Usage: include "dashjoin.secretEnvList" (dict "component" "aia" "env" .Values.aia.env "root" $)
*/}}
{{- define "dashjoin.secretEnvList" -}}
{{- $root := .root -}}
{{- $s := $root.Values.secrets | default dict -}}
{{- $out := list -}}
{{- if $s.enabled -}}
  {{- if and $s.existingSecret $s.encryptedData -}}
    {{- fail "secrets.existingSecret and secrets.encryptedData are mutually exclusive" -}}
  {{- end -}}
  {{- $defined := dict -}}
  {{- range (.env | default list) -}}
    {{- if .name }}{{ $_ := set $defined .name true }}{{ end -}}
  {{- end -}}
  {{- $generate := $s.generate | default dict -}}
  {{- $encrypted := $s.encryptedData | default dict -}}
  {{- $mapping := index ($s.env | default dict) .component | default dict -}}
  {{- range $envName := keys $mapping | sortAlpha -}}
    {{- $key := index $mapping $envName -}}
    {{- if and $key (not (hasKey $defined $envName)) -}}
      {{- $ref := dict -}}
      {{- if hasKey $generate $key -}}
        {{- $ref = dict "name" (include "dashjoin.generatedSecretName" $root) "key" $key -}}
      {{- else if $s.existingSecret -}}
        {{- $ref = dict "name" $s.existingSecret "key" $key "optional" true -}}
      {{- else if hasKey $encrypted $key -}}
        {{- $ref = dict "name" (include "dashjoin.secretName" $root) "key" $key -}}
      {{- end -}}
      {{- if $ref -}}
        {{- $out = append $out (dict "name" $envName "valueFrom" (dict "secretKeyRef" $ref)) -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- toJson $out -}}
{{- end }}

{{/*
Render a component's env list: user env (as before) plus secret references.
Without secrets.enabled the output is identical to "toYaml .env".

Usage: include "dashjoin.envWithSecrets" (dict "component" "aia" "env" .Values.aia.env "root" $)
*/}}
{{- define "dashjoin.envWithSecrets" -}}
{{- $secretEnv := include "dashjoin.secretEnvList" . | fromJsonArray -}}
{{- if $secretEnv -}}
{{- toYaml (concat (.env | default list) $secretEnv) -}}
{{- else -}}
{{- toYaml .env -}}
{{- end -}}
{{- end }}

{{/*
Extra env of the Dashjoin platform container, appended after envBase / env (JSON list):
  1. DASHJOIN_APPURL from dashjoin.appUrl (unless defined in env)
  2. secret env (secrets.env.dashjoin, see dashjoin.secretEnvList)
  3. DASHJOIN_GIT_USER / DASHJOIN_GIT_TOKEN from dashjoin.gitSecret (keys GITHUB_USER /
     GITHUB_TOKEN, optional refs), only if an app URL is configured, the vars are not
     defined by 1./2., and the plaintext URL does not contain credentials (user:token@),
     which Dashjoin would otherwise ignore in favor of DASHJOIN_GIT_*.
*/}}
{{- define "dashjoin.platformExtraEnv" -}}
{{- $root := . -}}
{{- $dj := .Values.dashjoin -}}
{{- $defined := concat ($dj.envBase | default list) ($dj.env | default list) -}}
{{- $names := dict -}}
{{- $url := "" -}}
{{- range $defined -}}
  {{- if .name }}{{ $_ := set $names .name true }}{{ end -}}
  {{- if and (eq .name "DASHJOIN_APPURL") .value }}{{ $url = toString .value }}{{ end -}}
{{- end -}}
{{- $out := list -}}
{{- if and $dj.appUrl (not (hasKey $names "DASHJOIN_APPURL")) -}}
  {{- $url = $dj.appUrl -}}
  {{- $out = append $out (dict "name" "DASHJOIN_APPURL" "value" $dj.appUrl) -}}
  {{- $_ := set $names "DASHJOIN_APPURL" true -}}
{{- end -}}
{{- $secretEnv := include "dashjoin.secretEnvList" (dict "component" "dashjoin" "env" (concat $defined $out) "root" $root) | fromJsonArray -}}
{{- range $secretEnv -}}
  {{- $_ := set $names .name true -}}
{{- end -}}
{{- $out = concat $out $secretEnv -}}
{{- $hasUrl := hasKey $names "DASHJOIN_APPURL" -}}
{{- $urlHasCredentials := regexMatch "://[^/@]+@" $url -}}
{{- if and $dj.gitSecret $hasUrl (not $urlHasCredentials) -}}
  {{- range $envName, $key := dict "DASHJOIN_GIT_USER" "GITHUB_USER" "DASHJOIN_GIT_TOKEN" "GITHUB_TOKEN" -}}
    {{- if not (hasKey $names $envName) -}}
      {{- $out = append $out (dict "name" $envName "valueFrom" (dict "secretKeyRef" (dict "name" $dj.gitSecret "key" $key "optional" true))) -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- toJson $out -}}
{{- end }}
